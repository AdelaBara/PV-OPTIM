from HR import db

from datetime import datetime
import json
from sqlalchemy.inspection import inspect
from flask_sqlalchemy import SQLAlchemy

from HR import bcrypt
from HR import login_manager
from flask_login import UserMixin
@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))


class User(db.Model, UserMixin):
    __tablename__='T_USERS'
    id=db.Column(db.Integer(), primary_key=True)
    username=db.Column(db.String(length=30), nullable=False, unique=True)
    email=db.Column(db.String(length=50), nullable=False, unique=True)
    password_hash=db.Column(db.String(length=60), nullable=False)

    @property
    def password(self):
        return self.password
    
    @password.setter
    def password(self, plain_text_password):
        self.password_hash=bcrypt.generate_password_hash(plain_text_password).decode('utf-8')
    
    def check_password_correction(self, attempted_password):
        return bcrypt.check_password_hash(self.password_hash, attempted_password) 
    

class Serializer(object):

    def serialize(self):
        return {c: getattr(self, c) for c in inspect(self).attrs.keys()}
    @staticmethod
    def serialize_list(l):
        return [m.serialize() for m in l]


class Appliances (db.Model, Serializer):
    __tablename__='T_APPLIANCES'
    id_appliance=db.Column(db.String(length=20), primary_key=True)
    name=db.Column(db.String(length=50), nullable=False)
    device_type=db.Column(db.String(length=50))
    description=db.Column(db.String(length=50))
    start_date=db.Column(db.Date(),default=datetime.utcnow)
    status=db.Column(db.String(length=10))
    required_operation_time=db.Column(db.Integer())
    time_between_oper=db.Column(db.Integer())
    actionable=db.Column(db.String(length=10))
    capacity=db.Column(db.Integer())
    power_max=db.Column(db.Integer())
    power_min=db.Column(db.Integer())
    soc_max=db.Column(db.Integer())
    soc_min=db.Column(db.Integer())
    flex_type=db.Column(db.String(length=10))
    max_oper_time=db.Column(db.Integer())
    priority=db.Column(db.Integer())

    Schedule=db.relationship('Schedule',backref='Appliances', lazy=True, primaryjoin="Appliances.id_appliance == Schedule.id_appliance")


    def serialize(self):
        d = Serializer.serialize(self)
        d['Schedule']=Serializer.serialize_list(d['Schedule'])
        return d
    
    def update(self, new_app):
        self.name=new_app.name
        self.device_type=new_app.device_type
        self.description=new_app.description
        self.start_date=new_app.start_date
        self.status=new_app.status
        self.required_operation_time=new_app.required_operation_time
        self.time_between_oper=new_app.time_between_oper
        self.actionable=new_app.actionable
        self.capacity=new_app.capacity
        self.power_max=new_app.power_max
        self.power_min=new_app.power_min
        self.soc_max=new_app.soc_max
        self.soc_min=new_app.soc_min
        self.flex_type=new_app.flex_type
        self.max_oper_time=new_app.max_oper_time
        self.priority=new_app.priority
        db.session.commit()
    
class Schedule(db.Model, Serializer):
    __tablename__ = 'T_APPLIANCE_SCHEDULE'
    id_appliance=db.Column(db.String(length=20), db.ForeignKey('T_APPLIANCES.id_appliance'), primary_key=True)
    operation=db.Column(db.String(length=20))
    start_time=db.Column(db.Date(),default=datetime.utcnow, primary_key=True)
    end_time=db.Column(db.Date(),default=datetime.utcnow)
    priority=db.Column(db.Integer())
    pmax=db.Column(db.Float())
    no_operations=db.Column(db.Integer(), default=1)
    duration=db.Column(db.Integer())
  
    def serialize(self):
        d = Serializer.serialize(self)
        return d

    def update(self, new_schedule):
        self.operation=new_schedule.operation
        self.start_time=new_schedule.start_time
        self.end_time=new_schedule.end_time
        self.priority=new_schedule.priority
        self.pmax=new_schedule.pmax
        self.no_operations=new_schedule.no_operations
        self.duration=new_schedule.duration
        db.session.commit()

class OptimalSchedule(db.Model, Serializer):
    __tablename__ = 'T_APPLIANCE_OPTIMAL_SCHEDULE'
    id_appliance=db.Column(db.String(length=20), db.ForeignKey('T_APPLIANCES.id_appliance'), primary_key=True)
    start_time=db.Column(db.Date(),default=datetime.utcnow, primary_key=True)
    end_time=db.Column(db.Date(),default=datetime.utcnow)
    pmax=db.Column(db.Float())
    active=db.Column(db.String(length=3))
    max_end_time=db.Column(db.Date(),default=datetime.utcnow)
      
    def __repr__(self):
        return f'Optimal_Schedule {self.id_appliance}'
    def serialize(self):
        d = Serializer.serialize(self)
        return d

    def update(self, new_schedule):
        self.start_time=new_schedule.start_time
        self.end_time=new_schedule.end_time
        self.pmax=new_schedule.pmax
        self.active=new_schedule.active
        self.max_end_time=new_schedule.max_end_time
        db.session.commit()

class InverterReadings(db.Model, Serializer):
    __tablename__ = 'T_INVERTER_READINGS'
    id_meter=db.Column(db.Integer(), primary_key=True)
    timestamp_r=db.Column(db.Date(),primary_key=True)
    power_load=db.Column(db.Float())
    power_gen=db.Column(db.Float())
    power_bat=db.Column(db.Float())
    power_grid=db.Column(db.Float())
    sd_capacity=db.Column(db.Float())

    def serialize(self):
        d = Serializer.serialize(self)
        return d

class AppReadings(db.Model, Serializer):
    __tablename__ = 'T_APPLIANCE_READINGS'
    id_appliance=db.Column(db.Integer(), primary_key=True)
    reading_date=db.Column(db.Date(),primary_key=True)
    active_power_cons=db.Column(db.Float())

    def serialize(self):
        d = Serializer.serialize(self)
        return d

class InverterForecast(db.Model, Serializer):
    __tablename__ = 'T_INVERTER_FORECAST'
    reading_date=db.Column(db.Date(),primary_key=True)
    power_forecast=db.Column(db.Float())
    p1=db.Column(db.Float())
    p2=db.Column(db.Float())
    p3=db.Column(db.Float())
    p4=db.Column(db.Float())
    p5=db.Column(db.Float())

    def serialize(self):
        d = Serializer.serialize(self)
        return d
    
    def PF_MIN_MAX(self):
        fmin=min(self.p1, self.p2, self.p3, self.p4, self.p5)
        if fmin<0: fmin=0
        fmax=max(self.p1, self.p2, self.p3, self.p4, self.p5)
        return fmin, fmax

class SASM_Params(db.Model, Serializer):
    __tablename__ = 'T_SASM_PARAMS'
    param_name=db.Column(db.String(length=50), primary_key=True)
    param_value=db.Column(db.Float())
    param_description=db.Column(db.String(length=250))
  
    def serialize(self):
        d = Serializer.serialize(self)
        return d

    def update(self, new_param):
        self.param_name=new_param.param_name
        self.param_value=new_param.param_value
        self.param_description=new_param.param_description
        db.session.commit()