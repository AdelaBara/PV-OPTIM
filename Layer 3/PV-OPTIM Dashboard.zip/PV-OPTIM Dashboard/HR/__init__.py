from flask import Flask, render_template
from flask_sqlalchemy import SQLAlchemy
#pt hash passwords: 
from flask_bcrypt import Bcrypt #necesita pip install flask-bcrypt 
#pt login: pip install flask_login
from flask_login import LoginManager

app=Flask(__name__)
#app.config["DEBUG"] = True
app.config['SQLALCHEMY_DATABASE_URI']='mysql+pymysql://pv_optim:pv_optim1234@localhost:3306/pv_optim'
app.config['SECRET_KEY']='693d7a0ee60d135acff9836c'
db=SQLAlchemy(app)
bcrypt=Bcrypt(app)
login_manager=LoginManager(app)
login_manager.login_view="login_page" #redirect to login page for login_requirred
login_manager.login_message_category= "info" 

from HR import routes