from HR import app
from flask import render_template, redirect, url_for, flash, request, jsonify
from HR.models import Appliances, Schedule , OptimalSchedule, InverterReadings, AppReadings, InverterForecast, SASM_Params, User 
from HR.forms import ApplianceForm, ScheduleForm, OptimalScheduleForm, DelScheduleForm, MRForm, AppRForm, AppStatusForm, OptimizeForm, SASM_ParamsForm,LoginForm, RegisterForm  
from HR import db
from flask_login import login_user, logout_user, login_required, current_user
from HR import PVOptimL3 as DAOA

import json
from sqlalchemy import exc, desc, asc, func
from datetime import datetime

import mysql.connector
import matplotlib.pyplot as plt
plt.switch_backend('agg')
from matplotlib.figure import Figure
from io import BytesIO
import base64

@app.route('/')
@app.route('/home')
def home_page():
    return render_template('home.html')


'''Appliances page'''
@app.route('/appliances', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def appliances_page():
    app_form=ApplianceForm() 
    if request.method=='POST':
        #Update appliance
        updated_id_appliance=request.form.get('updated_id_appliance') 
        print(updated_id_appliance)
        p_app_object=Appliances.query.filter_by(id_appliance=updated_id_appliance).first()
        if p_app_object:
            if app_form.validate_on_submit():
                new_app=Appliances(name=app_form.name.data, device_type=app_form.device_type.data, 
                    description=app_form.description.data, start_date=app_form.start_date.data,
                    status=app_form.status.data, required_operation_time=app_form.required_operation_time.data, 
                    time_between_oper=app_form.time_between_oper.data, actionable=app_form.actionable.data,
                    capacity=app_form.capacity.data,power_max=app_form.power_max.data,
                    power_min=app_form.power_min.data,soc_max=app_form.soc_max.data,
                    soc_min=app_form.soc_min.data,flex_type=app_form.flex_type.data,
                    max_oper_time=app_form.max_oper_time.data, priority=app_form.priority.data)
                try:
                    p_app_object.update(new_app)
                    flash (f"Congratulations! You updated {p_app_object}!", category='success')
                except exc.SQLAlchemyError as e:
                    flash(f'There is an error in update values: {e}', category='danger')    
            if app_form.errors!={}: #if there are some errors from the validators in forms.py
                for err_msg in app_form.errors.values():
                    flash(f'There is an error in update form: {err_msg}', category='danger')
        else:
            flash(f"Unfortunately something went wrong with the appliance's data!", category='danger')
        return redirect(url_for('appliances_page'))
    if request.method=='GET':
        appliances=Appliances.query.all() 
        return render_template('appliances.html',  appliances=appliances, app_form=app_form,title='Home Appliances')
    if request.method=='GET':
        appliances=Appliances.query.all() 
        return render_template('appliances.html',  appliances=appliances, app_form=app_form,title='Home Appliances')

'''Add new appliance page'''
@app.route('/new_appliance', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def new_appliance_page():
    new_app_form=ApplianceForm()
    if new_app_form.validate_on_submit():
        app_to_create=Appliances(id_appliance=new_app_form.id_appliance.data, name=new_app_form.name.data,
                                device_type=new_app_form.device_type.data, description=new_app_form.description.data,
                                start_date=new_app_form.start_date.data.strftime('%Y-%m-%d'), 
                                status=new_app_form.status.data, required_operation_time=new_app_form.required_operation_time.data,
                                time_between_oper=new_app_form.time_between_oper.data, actionable=new_app_form.actionable.data,
                                capacity=new_app_form.capacity.data, power_max=new_app_form.power_max.data,
                                power_min=new_app_form.power_min.data, soc_max=new_app_form.soc_max.data,
                                soc_min=new_app_form.soc_min.data, flex_type=new_app_form.flex_type.data,
                                max_oper_time=new_app_form.max_oper_time.data, priority=new_app_form.priority.data) 
        db.session.add(app_to_create)
        db.session.commit()
        flash(f'Appliance created succsessfully!', category='success')
        return redirect(url_for('appliances_page'))
    return render_template('new_app.html', app_form=new_app_form, title='Add new appliance')

'''Schedule appliances in Schedule Plan'''
@app.route('/schedule', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def schedule_page():
    #form update schedule
    sch_update_form=ScheduleForm()
    #form delete schedule
    delsch_form=DelScheduleForm ()
    
    if request.method=='POST':
        #update schedule
        updated_sch_id=request.form.get('updated_sch_id')
        updated_sch_start_time=request.form.get('updated_sch_start_time')
        s_item_object=Schedule.query.filter_by(id_appliance=updated_sch_id,start_time=updated_sch_start_time).first()
        print('update:',updated_sch_id)
        if s_item_object:
            if sch_update_form.validate_on_submit():
                app=Appliances.query.filter_by(id_appliance=updated_sch_id).first()
                if app.required_operation_time>sch_update_form.duration.data: 
                    rot=app.required_operation_time
                    flash(f'Duration was set to the minimum required operation time of the appliance!', category='warning')
                else: 
                    rot=sch_update_form.duration.data
                
                schedule_to_update=Schedule(operation=sch_update_form.operation.data,
                                        start_time=sch_update_form.day.data.strftime('%Y-%m-%d')+' '+sch_update_form.start_time.data.strftime('%H:%M'), 
                                        end_time=sch_update_form.day.data.strftime('%Y-%m-%d')+' ' +sch_update_form.end_time.data.strftime('%H:%M'), 
                                        priority=sch_update_form.priority.data, pmax=sch_update_form.pmax.data, no_operations=sch_update_form.no_operations.data,
                                        duration=rot) 
                try:
                    s_item_object.update(schedule_to_update)
                    flash (f"Congratulations! You updated {s_item_object}", category='success')
                except exc.SQLAlchemyError as e:
                    flash(f'There is an error in update values: {e}', category='danger')    
            if sch_update_form.errors!={}: #if there are some errors from the validators in forms.py
                for err_msg in sch_update_form.errors.values():
                    flash(f'There is an error in update form: {err_msg}', category='danger')
            return redirect(url_for('schedule_page'))

        #delete schedule
        deleted_sch_id=request.form.get('deleted_sch_id')
        deleted_sch_start_time=request.form.get('deleted_sch_start_time')
        s_item_object=Schedule.query.filter_by(id_appliance=deleted_sch_id,start_time=deleted_sch_start_time).first()
        if s_item_object:
            db.session.delete(s_item_object)
            db.session.commit()
            flash (f"Congratulations! You deleted {s_item_object.id_appliance} scheduled at {s_item_object.start_time}", category='success')
            return redirect(url_for('schedule_page'))
    if request.method=='GET':
        schedules=Schedule.query.order_by(desc(Schedule.start_time)).all() 
        return render_template('schedule.html', schedules=schedules, sch_update_form=sch_update_form, delsch_form=delsch_form, title='Appliances Schedule')

'''New Schedule to Plan'''
@app.route('/new_schedule', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def new_schedule_page():
    sch_form=ScheduleForm()
    if sch_form.validate_on_submit():
        app=Appliances.query.filter_by(id_appliance=sch_form.id_appliance.data).first()
        if app.required_operation_time>sch_form.duration.data: 
            rot=app.required_operation_time
            flash(f'Duration was set to the minimumrequired operation time of the appliance!', category='warning')
        else: 
            rot=sch_form.duration.data
        schedule_to_create=Schedule(id_appliance=sch_form.id_appliance.data, operation=sch_form.operation.data,
                                start_time=sch_form.day.data.strftime('%Y-%m-%d')+' '+sch_form.start_time.data.strftime('%H:%M'), 
                                end_time=sch_form.day.data.strftime('%Y-%m-%d')+' ' +sch_form.end_time.data.strftime('%H:%M'), 
                                priority=sch_form.priority.data, pmax=sch_form.pmax.data, no_operations=sch_form.no_operations.data,
                                duration=rot) 
        
        db.session.add(schedule_to_create)
        db.session.commit()
        flash(f'Schedule created succsessfully!', category='success')
        return redirect(url_for('schedule_page'))
    return render_template('new_schedule.html',  sch_form=sch_form, title='New Schedule')

'''Optimize page'''
@app.route('/optimize', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def optimize_page():
    OptimForm=OptimizeForm()
    #day=datetime.now().strftime('%Y-%m-%d')
    if request.method=='POST':
        day=request.form.get('day')   
        interval=int(request.form.get('interval'))   
        pcmax=int(request.form.get('pcmax')*1000)   
        '''Call PVOptimL3.py'''
        dfschplotT, CT_day, PG_day=DAOA.main_optim(day, interval, pcmax)
        fig = Figure()
        plt.rcParams.update({'font.size': 22})
        ax =dfschplotT['PV'].plot(x=None, linewidth=5, fontsize=22) 
        ax.set_ylabel('W',fontdict={'fontsize':24})
        ax.set_xlabel('Time',fontdict={'fontsize':24})
        cols=dfschplotT.columns.to_list()
        cols.remove('PV')
        cols=list(dict.fromkeys(cols))
        ax.set_title("Daily optimal schedule",pad=20, fontdict={'fontsize':24})
        ax.legend(loc=1,fontsize=20, title=None)
        sunalt = dfschplotT[cols].plot(x=None,figsize=(30,18), kind='bar',stacked=True,legend=True, ax=ax, fontsize=22).get_figure()
        buf = BytesIO()
        sunalt.savefig(buf, format='png')
        plt.close()
        buf.seek(0)
        buffer = b''.join(buf)
        b2 = base64.b64encode(buffer)
        sunalt2=b2.decode('utf-8')
        return render_template('optimize.html',OptimizeForm=OptimForm, title='Optimize the daily plan', sunalt=sunalt2)
    return render_template('optimize.html',OptimizeForm=OptimForm, title='Optimize the daily plan')
 
#View Optimal schedule page
@app.route('/optimal_schedule', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def optimal_schedule_page():
    #form pt actualizarea unui schedule
    sch_update_form=OptimalScheduleForm()
    #form pt stergerea unui schedule
    delsch_form=DelScheduleForm ()
    
    if request.method=='POST':
        #Actualizare schedule
        #din schedule.html preluam id_appliance si start_time pt scheudule actualizat
        updated_sch_id=request.form.get('updated_sch_id')
        updated_sch_start_time=request.form.get('updated_sch_start_time')
        #regasim inregistrarea
        s_item_object=OptimalSchedule.query.filter_by(id_appliance=updated_sch_id,start_time=updated_sch_start_time).first()
        print('update:',updated_sch_id)
        if s_item_object:
            if sch_update_form.validate_on_submit():
                app=Appliances.query.filter_by(id_appliance=updated_sch_id).first()
                if app.power_min>sch_update_form.pmax.data or app.power_max<sch_update_form.pmax.data: 
                    up_pmax=app.capacity
                    flash(f'Maximum power was set to the capacity of the appliance!', category='warning')
                else: 
                    up_pmax=sch_update_form.pmax.data
                schedule_to_update=OptimalSchedule(start_time=sch_update_form.day.data.strftime('%Y-%m-%d')+' '+sch_update_form.start_time.data.strftime('%H:%M'), 
                                        end_time=sch_update_form.day.data.strftime('%Y-%m-%d')+' ' +sch_update_form.end_time.data.strftime('%H:%M'), 
                                        pmax=up_pmax, active=sch_update_form.active.data, 
                                        max_end_time=sch_update_form.day.data.strftime('%Y-%m-%d')+' ' +sch_update_form.max_end_time.data.strftime('%H:%M')) 
                try:
                    s_item_object.update(schedule_to_update)
                    flash (f"Congratulations! You updated {s_item_object}", category='success')
                except exc.SQLAlchemyError as e:
                    flash(f'There is an error in update values: {e}', category='danger')    
            if sch_update_form.errors!={}: #if there are some errors from the validators in forms.py
                for err_msg in sch_update_form.errors.values():
                    flash(f'There is an error in update form: {err_msg}', category='danger')
            return redirect(url_for('optimal_schedule_page'))
 
        #delete schedule
        deleted_sch_id=request.form.get('deleted_sch_id')
        deleted_sch_start_time=request.form.get('deleted_sch_start_time')
        s_item_object=OptimalSchedule.query.filter_by(id_appliance=deleted_sch_id,start_time=deleted_sch_start_time).first()
        if s_item_object:
            db.session.delete(s_item_object)
            db.session.commit()
            flash (f"Congratulations! You deleted {s_item_object.id_appliance} scheduled at {s_item_object.start_time}", category='success')
            return redirect(url_for('optimal_schedule_page'))
    if request.method=='GET':
        schedules=OptimalSchedule.query.order_by(desc(OptimalSchedule.start_time)).all() #pt afisarea in tabel a programarilor
        return render_template('optimal_schedule.html', schedules=schedules, sch_update_form=sch_update_form, delsch_form=delsch_form, title='Daily Operation Schedule')

#New Schedule to Optimal Schedule
@app.route('/new_opt_schedule', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def new_opt_schedule_page():
    #form pt adaugarea unui schedule in Optimal Schedule Plan sau Appliances Daily Schedule
    sch_form=OptimalScheduleForm()
    if sch_form.validate_on_submit():
        app=Appliances.query.filter_by(id_appliance=sch_form.id_appliance.data).first()
        if app.power_min>sch_form.pmax.data or app.power_max<sch_form.pmax.data: 
            up_pmax=app.capacity
            flash(f'Maximum power was set to the capacity of the appliance!', category='warning')
        else: 
            up_pmax=sch_form.pmax.data
        schedule_to_create=OptimalSchedule(id_appliance=sch_form.id_appliance.data, start_time=sch_form.day.data.strftime('%Y-%m-%d')+' '+sch_form.start_time.data.strftime('%H:%M'), 
                                        end_time=sch_form.day.data.strftime('%Y-%m-%d')+' ' +sch_form.end_time.data.strftime('%H:%M'), 
                                        pmax=up_pmax, active=sch_form.active.data, 
                                        max_end_time=sch_form.day.data.strftime('%Y-%m-%d')+' ' +sch_form.max_end_time.data.strftime('%H:%M')) 
        
        db.session.add(schedule_to_create)
        db.session.commit()
        flash(f'Schedule created succsessfully!', category='success')
        return redirect(url_for('optimal_schedule_page'))
    return render_template('new_opt_schedule.html',  sch_form=sch_form, title='New Operation Schedule')

#Display chart with inverter readings
@app.route('/inverter_readings', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def inverter_readings_page():
    chart_labels=[]
    MR_values=[]
    load_values=[]
    grid_values=[]
    SOC_values=[]
    MR_form=MRForm()
    #day=datetime.now().strftime('%Y-%m-%d')
    day=request.form.get('day')    
    mr=InverterReadings.query.filter(func.date_format (InverterReadings.timestamp_r,'%Y-%m-%d')==day ).all() 

    for d in mr:
        chart_labels.append(d.timestamp_r.strftime('%H:%M'))
        MR_values.append(0 if d.power_gen is None else d.power_gen)
        load_values.append(0 if d.power_load is None else d.power_load)
        grid_values.append(0 if d.power_grid is None else  d.power_grid)
        SOC_values.append(0 if d.sd_capacity else d.sd_capacity)
        
    return render_template('inverter_readings.html',MR_form=MR_form, title='Daily consumption', labels=chart_labels, MR_values=MR_values, load_values=load_values,grid_values=grid_values, SOC_values=SOC_values)

#Display chart with appliance readings
@app.route('/app_readings', methods=['GET', 'POST'])
@login_required #redirect the user to the login page 
def app_readings_page():
    chart_labels=[]
    AppR_values=[]
    
    AppR_form=AppRForm()
    #day=datetime.now().strftime('%Y-%m-%d')
    day=request.form.get('day')    
    appliance=request.form.get('id_appliance')   
    appr=AppReadings.query.filter(func.date_format (AppReadings.reading_date,'%Y-%m-%d')==day, AppReadings.id_appliance==appliance).all() #afisam citirile

    for d in appr:
        chart_labels.append(d.reading_date.strftime('%H:%M'))
        AppR_values.append(d.active_power_cons)
        
    return render_template('app_readings.html',AppR_form=AppR_form, title='Appliances daily consumption', labels=chart_labels, AppR_values=AppR_values, )

#Display chart with inverter readings and forecast
@app.route('/inverter_forecast', methods=['GET', 'POST'])
@login_required #redirect the user to the login page
def inverter_forecast_page():
    MR_form=MRForm()
    #day=datetime.now().strftime('%Y-%m-%d')
    day=request.form.get('day')   

    '''inverter readings vs inverter forecast'''
    try:
        db_local_connection = mysql.connector.connect(
        host="localhost", 
        user="pv_optim",
        passwd="pv_optim1234", 
        database="pv_optim", port=3306, auth_plugin='mysql_native_password'
        )
    except:
        print('App warning! Could not connect to PV-OPTIM DB!')    
    sql_MRF="""select CONCAT(DATE_FORMAT(TIMESTAMP_R, '%Y-%m-%d %H'),':00') READING_DATE,hour(reading_date), AVG(POWER_GEN) POWER_GENERATED, AVG(power_forecast/1000) POWER_FORECAST 
    from T_INVERTER_READINGS M join T_INVERTER_FORECAST F on CONCAT(DATE_FORMAT(TIMESTAMP_R, '%Y-%m-%d %H'),':00')=READING_DATE 
    WHERE DATE_FORMAT(TIMESTAMP_R,'%Y-%m-%d' ) = DATE_FORMAT(%s,'%Y-%m-%d')
    GROUP BY CONCAT(DATE_FORMAT(TIMESTAMP_R, '%Y-%m-%d %H'),':00'), hour(reading_date)
    order by READING_DATE"""
    chart_labels=[]
    MR_values=[]
    MF_values=[]
    chart_labelsF=[]
    MFF_values=[]
    FMIN_values=[]
    FMAX_values=[]
    cursor =  db_local_connection.cursor()
    cursor.execute(sql_MRF, (day,))
    lmrf = cursor.fetchall()	
    cursor.close()
    for d in lmrf:
        chart_labels.append(d[0])
        MR_values.append(d[2])
        MF_values.append(d[3])
    
    '''Inverter forcast: min, max, avg'''
    lmf=InverterForecast.query.filter(func.date_format (InverterForecast.reading_date,'%Y-%m-%d')==day ).all() 
    for d in lmf:
        chart_labelsF.append(d.reading_date.strftime('%H:%M'))
        MFF_values.append(d.power_forecast/1000)
        FMIN_values.append(d.PF_MIN_MAX()[0]/1000)
        FMAX_values.append(d.PF_MIN_MAX()[1]/1000)
        
        
    return render_template('inverter_forecast.html',MR_form=MR_form, title='PV forecast and generation', labels=chart_labels, MR_values=MR_values,MF_values=MF_values, 
    MFF_values=MFF_values,labelsF=chart_labelsF, FMIN_values=FMIN_values,FMAX_values=FMAX_values )

#View SASM parameters page
@app.route('/SASM_Params', methods=['GET', 'POST'])
@login_required #redirect the user to the login page
def SASM_Params_page():
    #form pt actualizarea parametrilor
    param_update_form=SASM_ParamsForm()
    if request.method=='POST':
        #Actualizare params SASM
        #din SASM_Pramas.html preluam param_name actualizat
        updated_param_name=request.form.get('updated_param_name')
        #regasim inregistrarea
        s_item_object=SASM_Params.query.filter_by(param_name=updated_param_name).first()
        print('update:',updated_param_name)
        if s_item_object:
            if param_update_form.validate_on_submit():
                param_to_update=SASM_Params(param_name=updated_param_name, param_value=param_update_form.param_value.data,param_description=param_update_form.param_description.data) 
                try:
                    s_item_object.update(param_to_update)
                    flash (f"Congratulations! You updated {s_item_object}", category='success')
                except exc.SQLAlchemyError as e:
                    flash(f'There is an error in update values: {e}', category='danger')    
            if param_update_form.errors!={}: #if there are some errors from the validators in forms.py
                for err_msg in param_update_form.errors.values():
                    flash(f'There is an error in update form: {err_msg}', category='danger')
            return redirect(url_for('SASM_Params_page'))
    if request.method=='GET':
        SASM_Params_list=SASM_Params.query.order_by(asc(SASM_Params.param_name)).all() #pt afisarea in tabel a programarilor
        return render_template('SASM_Params.html', SASM_Params_list=SASM_Params_list, param_update_form=param_update_form, title='SASM Parameters Configuration')

@app.route('/register', methods=['GET', 'POST'])
def register_page():
    form=RegisterForm()
    if form.validate_on_submit():
        #de alocat id-ul incremental sau alta metoda
        user_to_create=User(id=108, username=form.username.data,
                            email=form.email.data,
                            password=form.password1.data) #password property din models.py
        db.session.add(user_to_create)
        db.session.commit()
        login_user(user_to_create)
        flash(f'Account created succsessfully! You are now logged in as : {user_to_create.username} ', category='success')

        return redirect(url_for('appliances_page'))
    if form.errors!={}: #if there are no errors from the validators in forms.py
        for err_msg in form.errors.values():
            flash(f'There is an error in register form: {err_msg}', category='danger')

    return render_template('register.html', form=form)

@app.route('/login', methods=['GET', 'POST'])
def login_page():
    form=LoginForm()
    if form.validate_on_submit():
        attempted_user=User.query.filter_by(username=form.username.data).first()
        if attempted_user and attempted_user.check_password_correction (attempted_password=form.password.data):
            login_user(attempted_user)
            flash(f'Success! You are logged in as: {attempted_user.username} ', category='success')
            return redirect(url_for('appliances_page'))
        else:
            flash(f'Username and password do not match! Please try again!', category='danger')
    return render_template('login.html', form=form)

@app.route('/logout')
def logout_page():
    logout_user()
    flash("You have been logged out!", category='info')
    return redirect(url_for('home_page'))