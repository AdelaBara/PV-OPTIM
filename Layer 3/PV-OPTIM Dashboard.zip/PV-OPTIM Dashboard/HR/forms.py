from flask_wtf import FlaskForm
from wtforms import StringField, IntegerField, SubmitField,PasswordField, DecimalField, SelectField, DateField, FloatField, TimeField

from wtforms.validators import Length, EqualTo, DataRequired, ValidationError, NumberRange, Email, Optional,NumberRange 
from HR.models import Appliances, SASM_Params, Schedule, AppReadings, User
from wtforms_alchemy import ModelForm #necesita pip install WTForms-Alchemy


class ScheduleForm(FlaskForm):

    def __init__(self, *args, **kwargs): 
        super().__init__(*args, **kwargs)

        self.id_appliance.choices = [
            (app.id_appliance, app.name) for app in Appliances.query.all()
        ]
    
    id_appliance=SelectField(label='Name:', validators=[Optional()])
    operation=IntegerField(label='Operation:',validators=[Optional()], default=1)
    day=DateField(label='Date:',format='%Y-%m-%d')
    start_time=TimeField(label='Start time:')
    end_time=TimeField(label='Last start time:')
    priority=IntegerField(label='Priority (High=1):',validators=[DataRequired()], default=1)
    pmax=FloatField(label='Maximum Power coefficient:',validators=[DataRequired()], default =1)
    no_operations=IntegerField(label='No of cycles:',validators=[DataRequired()], default=1)
    duration=IntegerField(label='Duration (minutes):',validators=[DataRequired()], default=10)

    submit=SubmitField(label='Save Schedule')
   
class DelScheduleForm(FlaskForm): 
    submit=SubmitField(label='Delete Schedule!')

class OptimalScheduleForm(FlaskForm):
    
    def __init__(self, *args, **kwargs): 
        super().__init__(*args, **kwargs)

        self.id_appliance.choices = [
            (app.id_appliance, app.name) for app in Appliances.query.all()
        ]

    id_appliance=SelectField(label='Name:', validators=[Optional()])
    day=DateField(label='Date:',format='%Y-%m-%d')
    start_time=TimeField(label='Start time:')
    end_time=TimeField(label='End time:')
    pmax=FloatField(label='Maximum power:', default =1)
    active=SelectField(label='Set active:',default='No', validators=[Optional()], choices=['Yes', 'No'])
    max_end_time=TimeField(label='Max end time:')
    submit=SubmitField(label='Confirm Schedule')

class ApplianceForm(FlaskForm):
    id_appliance=StringField(label='ID Appliance:')
    name=StringField(label='Name:',validators=[ DataRequired()])
    device_type=SelectField(label='Device type:',validators=[ DataRequired()], choices=['Interruptible', 'Shiftable','Battery'], id='device_type', validate_choice=False)
    description=StringField(label='Description:') 
    start_date=DateField(label='Start date:',format='%Y-%m-%d')
    status=SelectField(label='Status:',default='Active', validators=[Optional()], choices=['Active', 'Inactive'])
    required_operation_time=IntegerField(label='Required operation time (minutes):',  validators=[Optional()],default=10)
    time_between_oper=IntegerField(label='Time between operation (minutes):', validators=[Optional()], default=10)
    actionable=SelectField(label='Actionable (Yes/No):', validators=[Optional()], default='Yes', choices=['Yes', 'No'])
    capacity=IntegerField(label='Capacity (Wh):', validators=[Optional()], default=1000)
    power_max=FloatField(label='Maximum power (Wh):', validators=[Optional()], default=1000)
    power_min=FloatField(label='Minimum power (Wh):', validators=[Optional()], default=500)
    soc_max=FloatField(label='Maximum SOC (Wh):', validators=[Optional()], default=0)
    soc_min=FloatField(label='Minimum SOC (Wh):', validators=[Optional()], default=0)
    flex_type=SelectField(label='Flexibility type (Yes/No):', validators=[Optional()], default='Yes', choices=['Yes', 'No'])
    max_oper_time=IntegerField(label='Maximum operation time (minutes):',  validators=[Optional()],default=60)
    priority=IntegerField(label='Priority order (1 - High):',  validators=[Optional()],default=100)
   
    submit=SubmitField(label='Save Appliance')

class MRForm(FlaskForm): #used in routes.py for inverter readings
    day=DateField(label='Select day:',format='%Y-%m-%d')
    submit=SubmitField(label='Show readings')

class AppRForm(FlaskForm): #used in routes.py for applience readings
    def __init__(self, *args, **kwargs): 
        super().__init__(*args, **kwargs)

        self.id_appliance.choices = [
            (app.id_appliance, app.name) for app in Appliances.query.all()
        ]
    day=DateField(label='Select day:',format='%Y-%m-%d')
    id_appliance=SelectField(label='Appliance')
    submit=SubmitField(label='Show readings')

#___-remove
class AppStatusForm(FlaskForm): #utilizat in routes.py pt afisat status
    def __init__(self, *args, **kwargs): #pentru popularea id_appliance cu valori din BD
        super().__init__(*args, **kwargs)

        self.id_appliance.choices = [
            (app.id_appliance, app.name) for app in Appliances.query.all()
        ]
    
    id_appliance=SelectField(label='Appliance')
    #rot=IntegerField(label='Running time (minutes):',  validators=[Optional()],default=10)
    #tbo=IntegerField(label='Time between operations (minutes):',  validators=[Optional()],default=10)
    no_cycles=IntegerField(label='No of cycles:',  validators=[Optional(),NumberRange(min=1, max=20, message="min=1, max=20")],default=1)
    #status=StringField(label='Status:', default='Please select a device first')
    
    #submit=SubmitField(label='Start') #sunt 3 butoane submit definite in pagina html

class OptimizeForm(FlaskForm): #used in routes.py for optimization
    day=DateField(label='Select day:',format='%Y-%m-%d')
    interval=SelectField(label='Time interval (minutes):', validators=[Optional()], default=15, choices=[5, 10, 15, 20, 30, 60])
    pcmax=IntegerField(label='Maximum load power (kWh):', default=5)
    submit=SubmitField(label='Optimize the plan')

class SASM_ParamsForm(FlaskForm):
    def __init__(self, *args, **kwargs): 
        super().__init__(*args, **kwargs)
        self.param_name.choices = [
            (par.param_name) for par in SASM_Params.query.all()
        ]
    
    param_name=SelectField(label='Name:', validators=[Optional()])
    param_value=FloatField(label='Parameter value:', validators=[Optional()])
    param_description=StringField(label='Description:', validators=[Optional()])
    submit=SubmitField(label='Save parameter value')

class RegisterForm(FlaskForm):
    def validate_username(self, username_to_check):
        user=User.query.filter_by(username=username_to_check.data).first()
        if user:
            raise ValidationError('Username already exists! Please try a different username')
    def validate_email_adress(self, email_adress_to_check):
        email_adress=User.query.filter_by(email_adress=email_adress_to_check.data).first()
        if email_adress:
            raise ValidationError('Email already exists! Please try a different email')
    username=StringField(label='User Name:', validators=[Length(min=2, max=30), DataRequired()])
    email=StringField(label='Email Adress:', validators=[Email(), DataRequired()])
    password1=PasswordField(label='Password:', validators=[Length(min=6, max=30), DataRequired()])
    password2=PasswordField(label='Confirm Password:', validators=[EqualTo('password1'), DataRequired()])
    submit=SubmitField(label='Create Account')

class LoginForm(FlaskForm): #utilizat in routes.py pt login
    username=StringField(label='User Name:', validators=[DataRequired()])
    password=PasswordField(label='Password:', validators=[DataRequired()])
    submit=SubmitField(label='Sign in')